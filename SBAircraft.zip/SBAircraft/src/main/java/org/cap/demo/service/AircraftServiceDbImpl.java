package org.cap.demo.service;

import java.util.List;

import org.cap.demo.dao.IAircraftDao;
import org.cap.demo.dao.IAircraftDbDao;
import org.cap.demo.model.Aircraft;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service("aircraftDbService")
public class AircraftServiceDbImpl implements IAircraftService{

	@Autowired
	private IAircraftDbDao aircraftDbDao;
	

	@Autowired
	private IAircraftDao aircraftDao;
	
	
	
	
	@Override
	public List<Aircraft> getAllAircrafts() {
		return aircraftDbDao.findAll();
		
	}

	@Override
	public Aircraft findAircraft(int aircraftId) {
		
		return aircraftDbDao.getOne(aircraftId);
	}

	@Override
	public List<Aircraft> deleteAircraft(int aircraftId) {
		aircraftDbDao.deleteById(aircraftId);
		return aircraftDbDao.findAll();
	}

	@Override
	public List<Aircraft> createAircraft(Aircraft aircraft) {
		aircraftDbDao.save(aircraft);
		return aircraftDbDao.findAll();
	}

	@Override
	public List<Aircraft> updateAircraft(Aircraft aircraft) {
		aircraftDbDao.save(aircraft);
		return aircraftDbDao.findAll();
	}

	@Override
	public List<Aircraft> addAll() {
		aircraftDbDao.saveAll(aircraftDao.getAllAircrafts());
		return aircraftDbDao.findAll();
	}

	@Override
	public List<Aircraft> findByCrusingRange(double crusingRange) {
		// TODO Auto-generated method stub
		return aircraftDbDao.findByCrusingRange(crusingRange);
	}

	@Override
	public List<Aircraft> findByCrusingRangeAndAircraftId(double crusingrange, int aircraftId) {
		// TODO Auto-generated method stub
		return aircraftDbDao.findByCrusingRangeAndAircraftId(crusingrange, aircraftId);
	}

	@Override
	public List<Aircraft> findAlldetails(double maxcrusingrange, double crusingrange) {
		// TODO Auto-generated method stub
		return aircraftDbDao.findAlldetails(maxcrusingrange, crusingrange);
	}

	@Override
	public List<Aircraft> findAircraftByName(String aircraftName) {
		return aircraftDbDao.findByAircraftName(aircraftName);
	}

}
