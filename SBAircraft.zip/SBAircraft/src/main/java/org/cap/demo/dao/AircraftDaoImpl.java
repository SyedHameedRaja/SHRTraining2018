package org.cap.demo.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.demo.model.Aircraft;
import org.springframework.stereotype.Repository;

@Repository("aircraftDao")
public class AircraftDaoImpl implements IAircraftDao{

	private static AtomicInteger aircraftId=new AtomicInteger(1000);
	
	private static List<Aircraft> aircrafts=dummyDB();
	
	
	private static List<Aircraft> dummyDB(){
		List<Aircraft> aircrafts=new ArrayList<>();
		
		aircrafts.add(new Aircraft(aircraftId.incrementAndGet(), "INS-1234", 1290, new Date()));
		aircrafts.add(new Aircraft(aircraftId.incrementAndGet(), "Indigo-5678", 34566, new Date(2001-1900,3,12)));
		aircrafts.add(new Aircraft(aircraftId.incrementAndGet(), "Spicejet-1234", 123.90, new Date(2008-1900,3,5)));
		aircrafts.add(new Aircraft(aircraftId.incrementAndGet(), "JetAirways-890", 345.900, new Date(2009-1900,5,12)));
		aircrafts.add(new Aircraft(aircraftId.incrementAndGet(), "Indigo-1234", 1234.890, new Date(2012-1900,5,22)));
		
		return aircrafts;
	}
	
	@Override
	public List<Aircraft> getAllAircrafts() {
		
		return aircrafts;
	}

	@Override
	public Aircraft findAircraft(int aircraftId) {
		for(Aircraft aircraft:aircrafts) {
			if(aircraftId==aircraft.getAircraftId()) {
				return aircraft;
			}
		}
		return null;
	}

	@Override
	public List<Aircraft> deleteAircraft(int aircraftId) {
		boolean flag=false;
		Iterator<Aircraft> iterator= aircrafts.iterator();
		
		while(iterator.hasNext()) {
			Aircraft aircraft=iterator.next();
			
			if(aircraftId==aircraft.getAircraftId()) {
				iterator.remove();
				flag=true;
				break;
			}
		}
		
		if(flag)
			return aircrafts;
		else
			return null;
	}

	@Override
	public List<Aircraft> createAircraft(Aircraft aircraft) {
		aircrafts.add(aircraft);
		return aircrafts;
	}

	@Override
	public List<Aircraft> updateAircraft(Aircraft aircraft) {
		boolean flag=false;
		ListIterator<Aircraft> iterator=aircrafts.listIterator();
		while(iterator.hasNext()) {
			Aircraft aircraft2=iterator.next();
			
			if(aircraft.getAircraftId()==aircraft2.getAircraftId()) {
				iterator.set(aircraft);
				flag=true;
				break;
			}
		}
		
		if(!flag)
			aircrafts.add(aircraft);
		
		return aircrafts;
	}

}
