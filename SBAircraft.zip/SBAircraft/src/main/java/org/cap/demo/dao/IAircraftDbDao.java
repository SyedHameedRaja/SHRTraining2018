package org.cap.demo.dao;

import java.util.List;

import org.cap.demo.model.Aircraft;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository("aircraftDbDao")
public interface IAircraftDbDao 
	extends JpaRepository<Aircraft, Integer>{
	
	public List<Aircraft> findByCrusingRange(double crusingRange);
	
	public List<Aircraft> findByCrusingRangeAndAircraftId(
			double crusingrange,int aircraftId);
	
	/*@Query("from Aircraft a where a.crusingRange>=? and a.crusingRange<=?")
	public List<Aircraft> findAlldetails(int crusingrange,
			int maxcrusingrange);
*/
	
	@Query("from Aircraft a where a.crusingRange>=:minrange"
			+ " and a.crusingRange<=:maxrange")
	public List<Aircraft> findAlldetails(
			@Param("maxrange")double maxcrusingrange,
			@Param("minrange")double crusingrange
			);
	@Query("from Aircraft a where a.aircraftName like %:searchTerm%")
	public List<Aircraft> findByAircraftName(@Param("searchTerm")String aircraftName);

}
